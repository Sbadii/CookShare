package com.example.backendCookShare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendCookShareApplicationTests {

	@Test
	void contextLoads() {
	}

}
